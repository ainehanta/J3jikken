extern void lcd_init(void);
extern void lcd_cursor(int x, int y);
extern void lcd_clear(void);
extern void lcd_printstr(unsigned char *str);
extern void lcd_printch(unsigned char ch);
extern void wait1ms(int ms);
