#ifndef _LCD_UTIL_H_

void my_itoa(char*, int);
void turn_str(char*);

#endif
